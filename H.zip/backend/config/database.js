// database.js - ملف إعداد اتصال قاعدة البيانات

const mysql = require('mysql2/promise');
const config = require('./config');

// إنشاء مجمع اتصالات لقاعدة البيانات
const pool = mysql.createPool({
  host: config.database.host,
  user: config.database.user,
  password: config.database.password,
  database: config.database.database,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// إنشاء جداول قاعدة البيانات إذا لم تكن موجودة
async function initDatabase() {
  try {
    const connection = await pool.getConnection();
    
    // جدول المستخدمين
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        email_verified BOOLEAN DEFAULT FALSE,
        verification_token VARCHAR(100),
        token_expiry DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP NULL,
        account_type ENUM('free', 'basic', 'advanced', 'pro') DEFAULT 'free',
        subscription_id INT NULL
      )
    `);
    
    // جدول خطط الاشتراك
    await connection.query(`
      CREATE TABLE IF NOT EXISTS plans (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        max_views INT NOT NULL,
        features JSON,
        duration_days INT NOT NULL
      )
    `);
    
    // جدول الاشتراكات
    await connection.query(`
      CREATE TABLE IF NOT EXISTS subscriptions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        plan_id INT NOT NULL,
        start_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        end_date TIMESTAMP NOT NULL,
        status ENUM('active', 'expired', 'cancelled') DEFAULT 'active',
        payment_id INT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (plan_id) REFERENCES plans(id)
      )
    `);
    
    // جدول طلبات زيادة المشاهدات
    await connection.query(`
      CREATE TABLE IF NOT EXISTS view_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        tiktok_url VARCHAR(255) NOT NULL,
        requested_views INT NOT NULL,
        current_views INT DEFAULT 0,
        status ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        completed_at TIMESTAMP NULL,
        notes TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    `);
    
    // جدول سجل المشاهدات
    await connection.query(`
      CREATE TABLE IF NOT EXISTS view_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        request_id INT NOT NULL,
        views_added INT NOT NULL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        batch_id VARCHAR(50),
        status ENUM('success', 'failed') DEFAULT 'success',
        FOREIGN KEY (request_id) REFERENCES view_requests(id)
      )
    `);
    
    // جدول المدفوعات
    await connection.query(`
      CREATE TABLE IF NOT EXISTS payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        subscription_id INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        currency VARCHAR(3) DEFAULT 'USD',
        payment_method VARCHAR(50),
        transaction_id VARCHAR(100),
        status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (subscription_id) REFERENCES subscriptions(id)
      )
    `);
    
    // إدخال خطط الاشتراك الافتراضية
    await connection.query(`
      INSERT IGNORE INTO plans (name, description, price, max_views, features, duration_days)
      VALUES 
        ('free', 'المستوى المجاني', 0, 1000, '{"videos_per_month": 3, "views_per_hour": 150, "likes": false, "comments": false}', 30),
        ('basic', 'المستوى الأساسي', 9.99, 5000, '{"videos_per_month": 10, "views_per_hour": 400, "likes": true, "max_likes": 500, "comments": false}', 30),
        ('advanced', 'المستوى المتقدم', 19.99, 20000, '{"videos_per_month": 20, "views_per_hour": 650, "likes": true, "max_likes": 2000, "comments": true, "max_comments": 100}', 30),
        ('pro', 'المستوى الاحترافي', 49.99, 100000, '{"videos_per_month": 9999, "views_per_hour": 1250, "likes": true, "max_likes": 10000, "comments": true, "max_comments": 500, "shares": true, "max_shares": 1000}', 30)
    `);
    
    connection.release();
    console.log('تم إنشاء قاعدة البيانات بنجاح');
    
    return true;
  } catch (error) {
    console.error('خطأ في إنشاء قاعدة البيانات:', error);
    return false;
  }
}

module.exports = {
  pool,
  initDatabase
};
