// config.js - ملف الإعدادات الرئيسي للتطبيق

module.exports = {
  // إعدادات قاعدة البيانات
  database: {
    host: 'localhost',
    user: 'tiktok_views_user',
    password: 'secure_password',
    database: 'tiktok_views_db',
    port: 3306
  },
  
  // إعدادات الخادم
  server: {
    port: 3000,
    host: '0.0.0.0'
  },
  
  // إعدادات JWT للمصادقة
  jwt: {
    secret: 'your_jwt_secret_key',
    expiresIn: '24h'
  },
  
  // إعدادات البريد الإلكتروني
  email: {
    host: 'smtp.example.com',
    port: 587,
    secure: false,
    auth: {
      user: 'support@tiktokviews.com',
      pass: 'email_password'
    },
    from: 'support@tiktokviews.com'
  },
  
  // إعدادات زيادة المشاهدات
  viewIncrement: {
    // معدلات الزيادة التدريجية للمشاهدات (عدد المشاهدات في الساعة)
    rates: {
      free: 150,       // المستوى المجاني
      basic: 400,      // المستوى الأساسي
      advanced: 650,   // المستوى المتقدم
      pro: 1250        // المستوى الاحترافي
    },
    
    // نمط الزيادة التدريجية (النسبة المئوية من إجمالي المشاهدات)
    pattern: {
      startup: 0.15,    // مرحلة البداية البطيئة
      acceleration: 0.35, // مرحلة التسارع
      steady: 0.35,     // مرحلة الاستقرار
      slowdown: 0.15    // مرحلة التباطؤ
    },
    
    // الحد الأقصى للمشاهدات لكل مستوى
    maxViews: {
      free: 1000,
      basic: 5000,
      advanced: 20000,
      pro: 100000
    }
  }
};
