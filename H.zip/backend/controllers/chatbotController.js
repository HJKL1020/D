// chatbotController.js - وحدة التحكم بروبوت المحادثة الذكي

const chatbotService = require('../chatbot/chatbotService');

class ChatbotController {
  // الحصول على رسالة الترحيب
  getWelcomeMessage(req, res) {
    try {
      const welcomeMessage = chatbotService.getWelcomeMessage();
      
      res.status(200).json({
        success: true,
        message: welcomeMessage
      });
    } catch (error) {
      console.error('خطأ في الحصول على رسالة الترحيب:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء الحصول على رسالة الترحيب' });
    }
  }
  
  // معالجة رسالة المستخدم
  processMessage(req, res) {
    try {
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ success: false, message: 'الرسالة مطلوبة' });
      }
      
      const response = chatbotService.processMessage(message);
      
      res.status(200).json({
        success: true,
        response
      });
    } catch (error) {
      console.error('خطأ في معالجة رسالة المستخدم:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء معالجة رسالة المستخدم' });
    }
  }
  
  // الحصول على قائمة الأسئلة الشائعة
  getFAQs(req, res) {
    try {
      const faqs = chatbotService.getFAQs();
      
      res.status(200).json({
        success: true,
        faqs
      });
    } catch (error) {
      console.error('خطأ في الحصول على الأسئلة الشائعة:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء الحصول على الأسئلة الشائعة' });
    }
  }
}

module.exports = new ChatbotController();
