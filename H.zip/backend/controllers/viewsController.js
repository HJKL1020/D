// viewsController.js - وحدة التحكم بطلبات زيادة المشاهدات

const viewsModel = require('../models/viewsModel');
const userModel = require('../models/userModel');
const crypto = require('crypto');

class ViewsController {
  // إنشاء طلب جديد لزيادة المشاهدات
  async createViewRequest(req, res) {
    try {
      const userId = req.user.id;
      const { tiktokUrl, requestedViews } = req.body;
      
      if (!tiktokUrl || !requestedViews) {
        return res.status(400).json({ success: false, message: 'رابط تيك توك وعدد المشاهدات المطلوبة مطلوبان' });
      }
      
      // التحقق من أن عدد المشاهدات المطلوبة رقم صحيح موجب
      if (!Number.isInteger(requestedViews) || requestedViews <= 0) {
        return res.status(400).json({ success: false, message: 'عدد المشاهدات المطلوبة يجب أن يكون رقمًا صحيحًا موجبًا' });
      }
      
      const result = await viewsModel.createViewRequest(userId, tiktokUrl, requestedViews);
      
      if (!result.success) {
        return res.status(400).json(result);
      }
      
      res.status(201).json(result);
    } catch (error) {
      console.error('خطأ في إنشاء طلب زيادة المشاهدات:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء إنشاء طلب زيادة المشاهدات' });
    }
  }
  
  // الحصول على طلبات المستخدم
  async getUserRequests(req, res) {
    try {
      const userId = req.user.id;
      
      const requests = await viewsModel.getUserRequests(userId);
      
      res.status(200).json({
        success: true,
        requests
      });
    } catch (error) {
      console.error('خطأ في الحصول على طلبات المستخدم:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء الحصول على طلبات المستخدم' });
    }
  }
  
  // الحصول على تفاصيل طلب محدد
  async getRequestDetails(req, res) {
    try {
      const userId = req.user.id;
      const { requestId } = req.params;
      
      const request = await viewsModel.getRequestDetails(requestId, userId);
      
      if (!request) {
        return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
      }
      
      res.status(200).json({
        success: true,
        request
      });
    } catch (error) {
      console.error('خطأ في الحصول على تفاصيل الطلب:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء الحصول على تفاصيل الطلب' });
    }
  }
  
  // إلغاء طلب
  async cancelRequest(req, res) {
    try {
      const userId = req.user.id;
      const { requestId } = req.params;
      
      // التحقق من أن الطلب ينتمي للمستخدم
      const request = await viewsModel.getRequestDetails(requestId, userId);
      
      if (!request) {
        return res.status(404).json({ success: false, message: 'الطلب غير موجود' });
      }
      
      // التحقق من أن الطلب في حالة معلق
      if (request.status !== 'pending') {
        return res.status(400).json({ success: false, message: 'لا يمكن إلغاء طلب قيد التنفيذ أو مكتمل' });
      }
      
      // إلغاء الطلب
      await viewsModel.updateRequestStatus(requestId, 'failed', 'تم إلغاء الطلب من قبل المستخدم');
      
      res.status(200).json({
        success: true,
        message: 'تم إلغاء الطلب بنجاح'
      });
    } catch (error) {
      console.error('خطأ في إلغاء الطلب:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء إلغاء الطلب' });
    }
  }
  
  // معالجة الطلبات المعلقة (يتم استدعاؤها من خلال مهمة مجدولة)
  async processPendingRequests(req, res) {
    try {
      // التحقق من أن المستخدم مسؤول (يمكن إضافة هذا التحقق لاحقًا)
      
      const pendingRequests = await viewsModel.getPendingRequests();
      
      if (pendingRequests.length === 0) {
        return res.status(200).json({
          success: true,
          message: 'لا توجد طلبات معلقة للمعالجة'
        });
      }
      
      const batchId = crypto.randomBytes(8).toString('hex');
      const processedRequests = [];
      
      for (const request of pendingRequests) {
        // حساب عدد المشاهدات التي يجب إضافتها في هذه الدفعة
        const viewsToAdd = viewsModel.calculateNextBatchViews(request, request.account_type);
        
        // إضافة المشاهدات
        const result = await viewsModel.addViews(request.id, viewsToAdd, batchId);
        
        if (result.success) {
          processedRequests.push({
            requestId: request.id,
            viewsAdded: result.viewsAdded,
            currentViews: result.currentViews,
            isCompleted: result.isCompleted
          });
        }
      }
      
      res.status(200).json({
        success: true,
        message: `تمت معالجة ${processedRequests.length} طلب`,
        processedRequests
      });
    } catch (error) {
      console.error('خطأ في معالجة الطلبات المعلقة:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء معالجة الطلبات المعلقة' });
    }
  }
}

module.exports = new ViewsController();
