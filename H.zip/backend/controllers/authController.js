// authController.js - وحدة التحكم بالمصادقة

const userModel = require('../models/userModel');
const jwt = require('jsonwebtoken');
const config = require('../config/config');
const emailUtil = require('../utils/emailUtil');

class AuthController {
  // تسجيل مستخدم جديد
  async register(req, res) {
    try {
      const { username, email, password } = req.body;
      
      // التحقق من البيانات المدخلة
      if (!username || !email || !password) {
        return res.status(400).json({ success: false, message: 'جميع الحقول مطلوبة' });
      }
      
      // التحقق من صحة البريد الإلكتروني
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ success: false, message: 'البريد الإلكتروني غير صالح' });
      }
      
      // التحقق من قوة كلمة المرور
      if (password.length < 8) {
        return res.status(400).json({ success: false, message: 'يجب أن تكون كلمة المرور 8 أحرف على الأقل' });
      }
      
      // إنشاء المستخدم
      const user = await userModel.createUser(username, email, password);
      
      // إرسال بريد التحقق
      const verificationUrl = `${req.protocol}://${req.get('host')}/api/auth/verify-email/${user.verificationToken}`;
      await emailUtil.sendVerificationEmail(email, username, verificationUrl);
      
      res.status(201).json({
        success: true,
        message: 'تم إنشاء الحساب بنجاح. يرجى التحقق من بريدك الإلكتروني لتأكيد الحساب'
      });
    } catch (error) {
      console.error('خطأ في تسجيل المستخدم:', error);
      
      // التحقق من خطأ تكرار البريد الإلكتروني
      if (error.code === 'ER_DUP_ENTRY') {
        return res.status(400).json({ success: false, message: 'البريد الإلكتروني مستخدم بالفعل' });
      }
      
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء إنشاء الحساب' });
    }
  }
  
  // تأكيد البريد الإلكتروني
  async verifyEmail(req, res) {
    try {
      const { token } = req.params;
      
      const result = await userModel.verifyEmail(token);
      
      if (!result.success) {
        return res.status(400).json(result);
      }
      
      res.status(200).json(result);
    } catch (error) {
      console.error('خطأ في تأكيد البريد الإلكتروني:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء تأكيد البريد الإلكتروني' });
    }
  }
  
  // تسجيل الدخول
  async login(req, res) {
    try {
      const { email, password } = req.body;
      
      // التحقق من البيانات المدخلة
      if (!email || !password) {
        return res.status(400).json({ success: false, message: 'البريد الإلكتروني وكلمة المرور مطلوبان' });
      }
      
      const result = await userModel.login(email, password);
      
      if (!result.success) {
        return res.status(401).json(result);
      }
      
      // إنشاء رمز JWT
      const token = jwt.sign(
        { id: result.user.id, email: result.user.email },
        config.jwt.secret,
        { expiresIn: config.jwt.expiresIn }
      );
      
      res.status(200).json({
        success: true,
        message: 'تم تسجيل الدخول بنجاح',
        token,
        user: result.user
      });
    } catch (error) {
      console.error('خطأ في تسجيل الدخول:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء تسجيل الدخول' });
    }
  }
  
  // طلب استعادة كلمة المرور
  async requestPasswordReset(req, res) {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ success: false, message: 'البريد الإلكتروني مطلوب' });
      }
      
      const result = await userModel.requestPasswordReset(email);
      
      // إذا تم العثور على المستخدم، نرسل بريد إعادة تعيين كلمة المرور
      if (result.resetToken) {
        const resetUrl = `${req.protocol}://${req.get('host')}/reset-password/${result.resetToken}`;
        await emailUtil.sendPasswordResetEmail(email, resetUrl);
      }
      
      // نرسل نفس الرسالة سواء تم العثور على المستخدم أم لا (لأسباب أمنية)
      res.status(200).json({
        success: true,
        message: 'إذا كان البريد الإلكتروني مسجلاً، فسيتم إرسال رابط إعادة تعيين كلمة المرور'
      });
    } catch (error) {
      console.error('خطأ في طلب استعادة كلمة المرور:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء طلب استعادة كلمة المرور' });
    }
  }
  
  // إعادة تعيين كلمة المرور
  async resetPassword(req, res) {
    try {
      const { token } = req.params;
      const { password } = req.body;
      
      if (!password) {
        return res.status(400).json({ success: false, message: 'كلمة المرور الجديدة مطلوبة' });
      }
      
      if (password.length < 8) {
        return res.status(400).json({ success: false, message: 'يجب أن تكون كلمة المرور 8 أحرف على الأقل' });
      }
      
      const result = await userModel.resetPassword(token, password);
      
      if (!result.success) {
        return res.status(400).json(result);
      }
      
      res.status(200).json(result);
    } catch (error) {
      console.error('خطأ في إعادة تعيين كلمة المرور:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء إعادة تعيين كلمة المرور' });
    }
  }
}

module.exports = new AuthController();
