// subscriptionController.js - وحدة التحكم بالاشتراكات

const subscriptionModel = require('../models/subscriptionModel');
const userModel = require('../models/userModel');

class SubscriptionController {
  // الحصول على جميع خطط الاشتراك
  async getAllPlans(req, res) {
    try {
      const plans = await subscriptionModel.getAllPlans();
      
      res.status(200).json({
        success: true,
        plans
      });
    } catch (error) {
      console.error('خطأ في الحصول على خطط الاشتراك:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء الحصول على خطط الاشتراك' });
    }
  }
  
  // الحصول على اشتراك المستخدم الحالي
  async getUserSubscription(req, res) {
    try {
      const userId = req.user.id;
      
      const subscription = await subscriptionModel.getUserSubscription(userId);
      
      res.status(200).json({
        success: true,
        subscription
      });
    } catch (error) {
      console.error('خطأ في الحصول على اشتراك المستخدم:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء الحصول على اشتراك المستخدم' });
    }
  }
  
  // إنشاء اشتراك جديد
  async createSubscription(req, res) {
    try {
      const userId = req.user.id;
      const { planId, paymentMethod, transactionId } = req.body;
      
      if (!planId) {
        return res.status(400).json({ success: false, message: 'معرف خطة الاشتراك مطلوب' });
      }
      
      // الحصول على خطة الاشتراك
      const plan = await subscriptionModel.getPlanById(planId);
      
      if (!plan) {
        return res.status(404).json({ success: false, message: 'خطة الاشتراك غير موجودة' });
      }
      
      // إنشاء الاشتراك
      const subscriptionResult = await subscriptionModel.createSubscription(userId, planId);
      
      if (!subscriptionResult.success) {
        return res.status(400).json(subscriptionResult);
      }
      
      // إذا كانت الخطة مدفوعة، نسجل عملية الدفع
      if (plan.price > 0 && paymentMethod && transactionId) {
        await subscriptionModel.createPayment(
          userId,
          subscriptionResult.subscriptionId,
          plan.price,
          'USD',
          paymentMethod,
          transactionId
        );
      }
      
      res.status(201).json({
        success: true,
        message: 'تم إنشاء الاشتراك بنجاح',
        subscription: {
          id: subscriptionResult.subscriptionId,
          endDate: subscriptionResult.endDate,
          plan
        }
      });
    } catch (error) {
      console.error('خطأ في إنشاء الاشتراك:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء إنشاء الاشتراك' });
    }
  }
  
  // إلغاء الاشتراك
  async cancelSubscription(req, res) {
    try {
      const userId = req.user.id;
      const { subscriptionId } = req.params;
      
      // التحقق من أن الاشتراك ينتمي للمستخدم
      const subscription = await subscriptionModel.getUserSubscription(userId);
      
      if (!subscription || subscription.id != subscriptionId) {
        return res.status(404).json({ success: false, message: 'الاشتراك غير موجود' });
      }
      
      // إلغاء الاشتراك
      await subscriptionModel.updateSubscriptionStatus(subscriptionId, 'cancelled');
      
      res.status(200).json({
        success: true,
        message: 'تم إلغاء الاشتراك بنجاح'
      });
    } catch (error) {
      console.error('خطأ في إلغاء الاشتراك:', error);
      res.status(500).json({ success: false, message: 'حدث خطأ أثناء إلغاء الاشتراك' });
    }
  }
}

module.exports = new SubscriptionController();
