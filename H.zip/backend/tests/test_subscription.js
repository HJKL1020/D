// test_subscription.js - اختبار وظائف الاشتراكات

const axios = require('axios');
const assert = require('assert');

// عنوان الخادم المحلي
const API_URL = 'http://localhost:3000/api';

// اختبار الحصول على خطط الاشتراك
async function testGetAllPlans(token) {
  console.log('اختبار الحصول على خطط الاشتراك...');
  
  try {
    const response = await axios.get(`${API_URL}/subscriptions/plans`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    assert.strictEqual(response.status, 200);
    assert.strictEqual(response.data.success, true);
    assert.ok(Array.isArray(response.data.plans));
    assert.ok(response.data.plans.length > 0);
    
    console.log('✅ اختبار الحصول على خطط الاشتراك ناجح');
    
    return response.data.plans;
  } catch (error) {
    console.error('❌ فشل اختبار الحصول على خطط الاشتراك:', error.message);
    return null;
  }
}

// اختبار الحصول على اشتراك المستخدم
async function testGetUserSubscription(token) {
  console.log('اختبار الحصول على اشتراك المستخدم...');
  
  try {
    const response = await axios.get(`${API_URL}/subscriptions/user`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    assert.strictEqual(response.status, 200);
    assert.strictEqual(response.data.success, true);
    
    console.log('✅ اختبار الحصول على اشتراك المستخدم ناجح');
    console.log('اشتراك المستخدم:', response.data.subscription || 'لا يوجد اشتراك نشط');
    
    return response.data.subscription;
  } catch (error) {
    console.error('❌ فشل اختبار الحصول على اشتراك المستخدم:', error.message);
    return null;
  }
}

// اختبار إنشاء اشتراك جديد
async function testCreateSubscription(token, planId) {
  console.log('اختبار إنشاء اشتراك جديد...');
  
  try {
    const response = await axios.post(`${API_URL}/subscriptions`, {
      planId,
      paymentMethod: 'test',
      transactionId: 'test_' + Date.now()
    }, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    assert.strictEqual(response.status, 201);
    assert.strictEqual(response.data.success, true);
    assert.ok(response.data.subscription);
    
    console.log('✅ اختبار إنشاء اشتراك جديد ناجح');
    
    return response.data.subscription;
  } catch (error) {
    console.error('❌ فشل اختبار إنشاء اشتراك جديد:', error.message);
    return null;
  }
}

// تنفيذ الاختبارات
async function runTests(token) {
  console.log('بدء اختبارات الاشتراكات...');
  
  if (!token) {
    console.error('❌ لا يمكن اختبار الاشتراكات بدون رمز المصادقة');
    return false;
  }
  
  const plans = await testGetAllPlans(token);
  
  if (plans) {
    const userSubscription = await testGetUserSubscription(token);
    
    // إذا لم يكن لدى المستخدم اشتراك نشط، نقوم بإنشاء اشتراك جديد
    if (!userSubscription) {
      // نختار الخطة المجانية للاختبار
      const freePlan = plans.find(plan => plan.name === 'free');
      
      if (freePlan) {
        await testCreateSubscription(token, freePlan.id);
      }
    }
    
    console.log('تم اكتمال اختبارات الاشتراكات بنجاح');
    return true;
  }
  
  console.log('فشلت بعض اختبارات الاشتراكات');
  return false;
}

module.exports = { runTests };

// تنفيذ الاختبارات إذا تم تشغيل الملف مباشرة
if (require.main === module) {
  // يجب توفير رمز المصادقة كمتغير بيئة
  const token = process.env.AUTH_TOKEN;
  
  if (!token) {
    console.error('❌ يجب توفير رمز المصادقة كمتغير بيئة AUTH_TOKEN');
    process.exit(1);
  }
  
  runTests(token);
}
