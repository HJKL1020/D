// test_views.js - اختبار وظائف زيادة المشاهدات

const axios = require('axios');
const assert = require('assert');

// عنوان الخادم المحلي
const API_URL = 'http://localhost:3000/api';

// اختبار إنشاء طلب زيادة مشاهدات
async function testCreateViewRequest(token) {
  console.log('اختبار إنشاء طلب زيادة مشاهدات...');
  
  try {
    const response = await axios.post(`${API_URL}/views/request`, {
      tiktokUrl: 'https://www.tiktok.com/@username/video/1234567890123456789',
      requestedViews: 1000
    }, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    assert.strictEqual(response.status, 201);
    assert.strictEqual(response.data.success, true);
    assert.ok(response.data.requestId);
    
    console.log('✅ اختبار إنشاء طلب زيادة مشاهدات ناجح');
    
    return response.data.requestId;
  } catch (error) {
    console.error('❌ فشل اختبار إنشاء طلب زيادة مشاهدات:', error.message);
    return null;
  }
}

// اختبار الحصول على طلبات المستخدم
async function testGetUserRequests(token) {
  console.log('اختبار الحصول على طلبات المستخدم...');
  
  try {
    const response = await axios.get(`${API_URL}/views/requests`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    assert.strictEqual(response.status, 200);
    assert.strictEqual(response.data.success, true);
    assert.ok(Array.isArray(response.data.requests));
    
    console.log('✅ اختبار الحصول على طلبات المستخدم ناجح');
    console.log(`عدد الطلبات: ${response.data.requests.length}`);
    
    return response.data.requests;
  } catch (error) {
    console.error('❌ فشل اختبار الحصول على طلبات المستخدم:', error.message);
    return null;
  }
}

// اختبار الحصول على تفاصيل طلب محدد
async function testGetRequestDetails(token, requestId) {
  console.log('اختبار الحصول على تفاصيل طلب محدد...');
  
  try {
    const response = await axios.get(`${API_URL}/views/request/${requestId}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    assert.strictEqual(response.status, 200);
    assert.strictEqual(response.data.success, true);
    assert.ok(response.data.request);
    
    console.log('✅ اختبار الحصول على تفاصيل طلب محدد ناجح');
    
    return response.data.request;
  } catch (error) {
    console.error('❌ فشل اختبار الحصول على تفاصيل طلب محدد:', error.message);
    return null;
  }
}

// اختبار معالجة الطلبات المعلقة
async function testProcessPendingRequests(token) {
  console.log('اختبار معالجة الطلبات المعلقة...');
  
  try {
    const response = await axios.post(`${API_URL}/views/process`, {}, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    assert.strictEqual(response.status, 200);
    assert.strictEqual(response.data.success, true);
    
    console.log('✅ اختبار معالجة الطلبات المعلقة ناجح');
    console.log(`تمت معالجة ${response.data.processedRequests?.length || 0} طلب`);
    
    return response.data.processedRequests;
  } catch (error) {
    console.error('❌ فشل اختبار معالجة الطلبات المعلقة:', error.message);
    return null;
  }
}

// تنفيذ الاختبارات
async function runTests(token) {
  console.log('بدء اختبارات زيادة المشاهدات...');
  
  if (!token) {
    console.error('❌ لا يمكن اختبار زيادة المشاهدات بدون رمز المصادقة');
    return false;
  }
  
  // الحصول على طلبات المستخدم الحالية
  const userRequests = await testGetUserRequests(token);
  
  if (userRequests !== null) {
    let requestId;
    
    // إذا كان لدى المستخدم طلبات سابقة، نستخدم أول طلب للاختبار
    if (userRequests.length > 0) {
      requestId = userRequests[0].id;
    } else {
      // إنشاء طلب جديد للاختبار
      requestId = await testCreateViewRequest(token);
    }
    
    if (requestId) {
      // اختبار الحصول على تفاصيل الطلب
      await testGetRequestDetails(token, requestId);
      
      // اختبار معالجة الطلبات المعلقة
      await testProcessPendingRequests(token);
      
      console.log('تم اكتمال اختبارات زيادة المشاهدات بنجاح');
      return true;
    }
  }
  
  console.log('فشلت بعض اختبارات زيادة المشاهدات');
  return false;
}

module.exports = { runTests };

// تنفيذ الاختبارات إذا تم تشغيل الملف مباشرة
if (require.main === module) {
  // يجب توفير رمز المصادقة كمتغير بيئة
  const token = process.env.AUTH_TOKEN;
  
  if (!token) {
    console.error('❌ يجب توفير رمز المصادقة كمتغير بيئة AUTH_TOKEN');
    process.exit(1);
  }
  
  runTests(token);
}
