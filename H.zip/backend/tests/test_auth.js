// test_auth.js - اختبار وظائف المصادقة

const axios = require('axios');
const assert = require('assert');

// عنوان الخادم المحلي
const API_URL = 'http://localhost:3000/api';

// بيانات اختبار
const testUser = {
  username: 'test_user',
  email: 'test@example.com',
  password: 'password123'
};

// اختبار التسجيل
async function testRegistration() {
  console.log('اختبار التسجيل...');
  
  try {
    const response = await axios.post(`${API_URL}/auth/register`, testUser);
    
    assert.strictEqual(response.status, 201);
    assert.strictEqual(response.data.success, true);
    console.log('✅ اختبار التسجيل ناجح');
    
    return true;
  } catch (error) {
    if (error.response && error.response.status === 400 && error.response.data.message.includes('البريد الإلكتروني مستخدم بالفعل')) {
      console.log('⚠️ المستخدم موجود بالفعل، المتابعة إلى اختبار تسجيل الدخول');
      return true;
    }
    
    console.error('❌ فشل اختبار التسجيل:', error.message);
    return false;
  }
}

// اختبار تسجيل الدخول
async function testLogin() {
  console.log('اختبار تسجيل الدخول...');
  
  try {
    const response = await axios.post(`${API_URL}/auth/login`, {
      email: testUser.email,
      password: testUser.password
    });
    
    assert.strictEqual(response.status, 200);
    assert.strictEqual(response.data.success, true);
    assert.ok(response.data.token);
    
    console.log('✅ اختبار تسجيل الدخول ناجح');
    
    return response.data.token;
  } catch (error) {
    console.error('❌ فشل اختبار تسجيل الدخول:', error.message);
    return null;
  }
}

// اختبار استعادة كلمة المرور
async function testPasswordReset() {
  console.log('اختبار طلب استعادة كلمة المرور...');
  
  try {
    const response = await axios.post(`${API_URL}/auth/request-reset`, {
      email: testUser.email
    });
    
    assert.strictEqual(response.status, 200);
    assert.strictEqual(response.data.success, true);
    
    console.log('✅ اختبار طلب استعادة كلمة المرور ناجح');
    
    return true;
  } catch (error) {
    console.error('❌ فشل اختبار طلب استعادة كلمة المرور:', error.message);
    return false;
  }
}

// تنفيذ الاختبارات
async function runTests() {
  console.log('بدء اختبارات المصادقة...');
  
  const registrationSuccess = await testRegistration();
  
  if (registrationSuccess) {
    const token = await testLogin();
    
    if (token) {
      await testPasswordReset();
      
      console.log('تم اكتمال اختبارات المصادقة بنجاح');
      return token;
    }
  }
  
  console.log('فشلت بعض اختبارات المصادقة');
  return null;
}

module.exports = { runTests };

// تنفيذ الاختبارات إذا تم تشغيل الملف مباشرة
if (require.main === module) {
  runTests();
}
