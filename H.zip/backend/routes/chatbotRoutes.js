// chatbotRoutes.js - مسارات روبوت المحادثة الذكي

const express = require('express');
const router = express.Router();
const chatbotController = require('../controllers/chatbotController');

// الحصول على رسالة الترحيب
router.get('/welcome', chatbotController.getWelcomeMessage);

// معالجة رسالة المستخدم
router.post('/message', chatbotController.processMessage);

// الحصول على قائمة الأسئلة الشائعة
router.get('/faqs', chatbotController.getFAQs);

module.exports = router;
