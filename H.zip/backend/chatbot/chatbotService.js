// chatbotService.js - خدمة روبوت المحادثة الذكي

const config = require('./chatbotConfig');

class ChatbotService {
  constructor() {
    this.config = config;
  }
  
  // معالجة رسالة المستخدم والرد عليها
  processMessage(message) {
    // إذا كانت الرسالة فارغة، نرجع رسالة الترحيب
    if (!message || message.trim() === '') {
      return {
        text: this.config.bot.welcomeMessage,
        isBot: true
      };
    }
    
    // البحث عن إجابة مناسبة في قاعدة المعرفة
    const response = this.findResponse(message);
    
    return {
      text: response,
      isBot: true
    };
  }
  
  // البحث عن إجابة مناسبة في قاعدة المعرفة
  findResponse(message) {
    // تحويل الرسالة إلى أحرف صغيرة وإزالة الفراغات الزائدة
    const normalizedMessage = message.trim().toLowerCase();
    
    // حساب درجة التطابق لكل سؤال في قاعدة المعرفة
    const matches = this.config.knowledgeBase.map(item => {
      const score = this.calculateMatchScore(normalizedMessage, item.keywords);
      return { item, score };
    });
    
    // ترتيب النتائج حسب درجة التطابق
    matches.sort((a, b) => b.score - a.score);
    
    // إذا كانت أعلى درجة تطابق أكبر من الحد الأدنى، نرجع الإجابة المناسبة
    if (matches.length > 0 && matches[0].score > 0.3) {
      return matches[0].item.answer;
    }
    
    // إذا لم يتم العثور على إجابة مناسبة، نرجع رد افتراضي عشوائي
    return this.getRandomDefaultResponse();
  }
  
  // حساب درجة التطابق بين الرسالة والكلمات المفتاحية
  calculateMatchScore(message, keywords) {
    let score = 0;
    
    // البحث عن كل كلمة مفتاحية في الرسالة
    for (const keyword of keywords) {
      if (message.includes(keyword.toLowerCase())) {
        score += 1 / keywords.length;
      }
    }
    
    return score;
  }
  
  // الحصول على رد افتراضي عشوائي
  getRandomDefaultResponse() {
    const index = Math.floor(Math.random() * this.config.defaultResponses.length);
    return this.config.defaultResponses[index];
  }
  
  // الحصول على رسالة الترحيب
  getWelcomeMessage() {
    return {
      text: this.config.bot.welcomeMessage,
      isBot: true
    };
  }
  
  // الحصول على قائمة الأسئلة الشائعة
  getFAQs() {
    return this.config.knowledgeBase.map(item => ({
      question: item.question,
      answer: item.answer
    }));
  }
}

module.exports = new ChatbotService();
