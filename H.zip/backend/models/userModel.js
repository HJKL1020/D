// userModel.js - نموذج المستخدم

const { pool } = require('../config/database');
const bcrypt = require('bcrypt');
const crypto = require('crypto');

class UserModel {
  // إنشاء مستخدم جديد
  async createUser(username, email, password) {
    try {
      // تشفير كلمة المرور
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(password, saltRounds);
      
      // إنشاء رمز التحقق
      const verificationToken = crypto.randomBytes(32).toString('hex');
      
      // حساب تاريخ انتهاء صلاحية الرمز (24 ساعة من الآن)
      const now = new Date();
      const tokenExpiry = new Date(now.getTime() + 24 * 60 * 60 * 1000);
      
      // إدخال المستخدم في قاعدة البيانات
      const [result] = await pool.query(
        'INSERT INTO users (username, email, password_hash, verification_token, token_expiry) VALUES (?, ?, ?, ?, ?)',
        [username, email, passwordHash, verificationToken, tokenExpiry]
      );
      
      return {
        id: result.insertId,
        username,
        email,
        verificationToken
      };
    } catch (error) {
      console.error('خطأ في إنشاء المستخدم:', error);
      throw error;
    }
  }
  
  // التحقق من البريد الإلكتروني
  async verifyEmail(token) {
    try {
      const [rows] = await pool.query(
        'SELECT id FROM users WHERE verification_token = ? AND token_expiry > NOW() AND email_verified = FALSE',
        [token]
      );
      
      if (rows.length === 0) {
        return { success: false, message: 'رمز التحقق غير صالح أو منتهي الصلاحية' };
      }
      
      const userId = rows[0].id;
      
      // تحديث حالة التحقق
      await pool.query(
        'UPDATE users SET email_verified = TRUE, verification_token = NULL, token_expiry = NULL WHERE id = ?',
        [userId]
      );
      
      return { success: true, message: 'تم التحقق من البريد الإلكتروني بنجاح' };
    } catch (error) {
      console.error('خطأ في التحقق من البريد الإلكتروني:', error);
      throw error;
    }
  }
  
  // تسجيل الدخول
  async login(email, password) {
    try {
      const [rows] = await pool.query(
        'SELECT id, username, email, password_hash, email_verified, account_type FROM users WHERE email = ?',
        [email]
      );
      
      if (rows.length === 0) {
        return { success: false, message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
      }
      
      const user = rows[0];
      
      // التحقق من كلمة المرور
      const passwordMatch = await bcrypt.compare(password, user.password_hash);
      
      if (!passwordMatch) {
        return { success: false, message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
      }
      
      // التحقق من تأكيد البريد الإلكتروني
      if (!user.email_verified) {
        return { success: false, message: 'يرجى تأكيد بريدك الإلكتروني قبل تسجيل الدخول' };
      }
      
      // تحديث آخر تسجيل دخول
      await pool.query(
        'UPDATE users SET last_login = NOW() WHERE id = ?',
        [user.id]
      );
      
      return {
        success: true,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          accountType: user.account_type
        }
      };
    } catch (error) {
      console.error('خطأ في تسجيل الدخول:', error);
      throw error;
    }
  }
  
  // استعادة كلمة المرور
  async requestPasswordReset(email) {
    try {
      const [rows] = await pool.query(
        'SELECT id FROM users WHERE email = ?',
        [email]
      );
      
      if (rows.length === 0) {
        // لا نكشف ما إذا كان البريد الإلكتروني موجودًا أم لا لأسباب أمنية
        return { success: true, message: 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني' };
      }
      
      const userId = rows[0].id;
      
      // إنشاء رمز إعادة تعيين
      const resetToken = crypto.randomBytes(32).toString('hex');
      
      // حساب تاريخ انتهاء صلاحية الرمز (1 ساعة من الآن)
      const now = new Date();
      const tokenExpiry = new Date(now.getTime() + 1 * 60 * 60 * 1000);
      
      // تحديث رمز إعادة التعيين
      await pool.query(
        'UPDATE users SET verification_token = ?, token_expiry = ? WHERE id = ?',
        [resetToken, tokenExpiry, userId]
      );
      
      return {
        success: true,
        message: 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني',
        resetToken
      };
    } catch (error) {
      console.error('خطأ في طلب إعادة تعيين كلمة المرور:', error);
      throw error;
    }
  }
  
  // إعادة تعيين كلمة المرور
  async resetPassword(token, newPassword) {
    try {
      const [rows] = await pool.query(
        'SELECT id FROM users WHERE verification_token = ? AND token_expiry > NOW()',
        [token]
      );
      
      if (rows.length === 0) {
        return { success: false, message: 'رمز إعادة التعيين غير صالح أو منتهي الصلاحية' };
      }
      
      const userId = rows[0].id;
      
      // تشفير كلمة المرور الجديدة
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(newPassword, saltRounds);
      
      // تحديث كلمة المرور
      await pool.query(
        'UPDATE users SET password_hash = ?, verification_token = NULL, token_expiry = NULL WHERE id = ?',
        [passwordHash, userId]
      );
      
      return { success: true, message: 'تم إعادة تعيين كلمة المرور بنجاح' };
    } catch (error) {
      console.error('خطأ في إعادة تعيين كلمة المرور:', error);
      throw error;
    }
  }
  
  // الحصول على معلومات المستخدم
  async getUserById(userId) {
    try {
      const [rows] = await pool.query(
        `SELECT u.id, u.username, u.email, u.account_type, u.created_at, u.last_login,
         s.id as subscription_id, s.start_date, s.end_date, s.status,
         p.name as plan_name, p.max_views, p.features
         FROM users u
         LEFT JOIN subscriptions s ON u.subscription_id = s.id
         LEFT JOIN plans p ON s.plan_id = p.id
         WHERE u.id = ?`,
        [userId]
      );
      
      if (rows.length === 0) {
        return null;
      }
      
      const user = rows[0];
      
      return {
        id: user.id,
        username: user.username,
        email: user.email,
        accountType: user.account_type,
        createdAt: user.created_at,
        lastLogin: user.last_login,
        subscription: user.subscription_id ? {
          id: user.subscription_id,
          startDate: user.start_date,
          endDate: user.end_date,
          status: user.status,
          plan: {
            name: user.plan_name,
            maxViews: user.max_views,
            features: JSON.parse(user.features)
          }
        } : null
      };
    } catch (error) {
      console.error('خطأ في الحصول على معلومات المستخدم:', error);
      throw error;
    }
  }
  
  // تحديث نوع حساب المستخدم
  async updateAccountType(userId, accountType, subscriptionId) {
    try {
      await pool.query(
        'UPDATE users SET account_type = ?, subscription_id = ? WHERE id = ?',
        [accountType, subscriptionId, userId]
      );
      
      return { success: true };
    } catch (error) {
      console.error('خطأ في تحديث نوع الحساب:', error);
      throw error;
    }
  }
}

module.exports = new UserModel();
