// subscriptionModel.js - نموذج الاشتراكات

const { pool } = require('../config/database');

class SubscriptionModel {
  // الحصول على جميع خطط الاشتراك
  async getAllPlans() {
    try {
      const [rows] = await pool.query('SELECT * FROM plans ORDER BY price ASC');
      
      return rows.map(plan => ({
        id: plan.id,
        name: plan.name,
        description: plan.description,
        price: plan.price,
        maxViews: plan.max_views,
        features: JSON.parse(plan.features),
        durationDays: plan.duration_days
      }));
    } catch (error) {
      console.error('خطأ في الحصول على خطط الاشتراك:', error);
      throw error;
    }
  }
  
  // الحصول على خطة اشتراك محددة
  async getPlanById(planId) {
    try {
      const [rows] = await pool.query('SELECT * FROM plans WHERE id = ?', [planId]);
      
      if (rows.length === 0) {
        return null;
      }
      
      const plan = rows[0];
      
      return {
        id: plan.id,
        name: plan.name,
        description: plan.description,
        price: plan.price,
        maxViews: plan.max_views,
        features: JSON.parse(plan.features),
        durationDays: plan.duration_days
      };
    } catch (error) {
      console.error('خطأ في الحصول على خطة الاشتراك:', error);
      throw error;
    }
  }
  
  // إنشاء اشتراك جديد
  async createSubscription(userId, planId, paymentId = null) {
    try {
      // الحصول على مدة الاشتراك من خطة الاشتراك
      const [planRows] = await pool.query('SELECT duration_days FROM plans WHERE id = ?', [planId]);
      
      if (planRows.length === 0) {
        return { success: false, message: 'خطة الاشتراك غير موجودة' };
      }
      
      const durationDays = planRows[0].duration_days;
      
      // حساب تاريخ انتهاء الاشتراك
      const now = new Date();
      const endDate = new Date(now.getTime() + durationDays * 24 * 60 * 60 * 1000);
      
      // إدخال الاشتراك في قاعدة البيانات
      const [result] = await pool.query(
        'INSERT INTO subscriptions (user_id, plan_id, end_date, payment_id) VALUES (?, ?, ?, ?)',
        [userId, planId, endDate, paymentId]
      );
      
      // تحديث نوع حساب المستخدم
      const [planNameRows] = await pool.query('SELECT name FROM plans WHERE id = ?', [planId]);
      const accountType = planNameRows[0].name;
      
      await pool.query(
        'UPDATE users SET account_type = ?, subscription_id = ? WHERE id = ?',
        [accountType, result.insertId, userId]
      );
      
      return {
        success: true,
        subscriptionId: result.insertId,
        endDate
      };
    } catch (error) {
      console.error('خطأ في إنشاء الاشتراك:', error);
      throw error;
    }
  }
  
  // الحصول على اشتراك المستخدم الحالي
  async getUserSubscription(userId) {
    try {
      const [rows] = await pool.query(
        `SELECT s.id, s.start_date, s.end_date, s.status, s.payment_id,
         p.id as plan_id, p.name as plan_name, p.description as plan_description,
         p.price, p.max_views, p.features, p.duration_days
         FROM subscriptions s
         JOIN plans p ON s.plan_id = p.id
         WHERE s.user_id = ? AND s.status = 'active'
         ORDER BY s.start_date DESC
         LIMIT 1`,
        [userId]
      );
      
      if (rows.length === 0) {
        return null;
      }
      
      const subscription = rows[0];
      
      return {
        id: subscription.id,
        startDate: subscription.start_date,
        endDate: subscription.end_date,
        status: subscription.status,
        paymentId: subscription.payment_id,
        plan: {
          id: subscription.plan_id,
          name: subscription.plan_name,
          description: subscription.plan_description,
          price: subscription.price,
          maxViews: subscription.max_views,
          features: JSON.parse(subscription.features),
          durationDays: subscription.duration_days
        }
      };
    } catch (error) {
      console.error('خطأ في الحصول على اشتراك المستخدم:', error);
      throw error;
    }
  }
  
  // تحديث حالة الاشتراك
  async updateSubscriptionStatus(subscriptionId, status) {
    try {
      await pool.query(
        'UPDATE subscriptions SET status = ? WHERE id = ?',
        [status, subscriptionId]
      );
      
      // إذا تم إلغاء الاشتراك أو انتهت صلاحيته، نعيد المستخدم إلى المستوى المجاني
      if (status === 'cancelled' || status === 'expired') {
        const [rows] = await pool.query('SELECT user_id FROM subscriptions WHERE id = ?', [subscriptionId]);
        
        if (rows.length > 0) {
          const userId = rows[0].user_id;
          
          await pool.query(
            'UPDATE users SET account_type = "free", subscription_id = NULL WHERE id = ?',
            [userId]
          );
        }
      }
      
      return { success: true };
    } catch (error) {
      console.error('خطأ في تحديث حالة الاشتراك:', error);
      throw error;
    }
  }
  
  // إنشاء سجل دفع
  async createPayment(userId, subscriptionId, amount, currency, paymentMethod, transactionId) {
    try {
      const [result] = await pool.query(
        'INSERT INTO payments (user_id, subscription_id, amount, currency, payment_method, transaction_id, status) VALUES (?, ?, ?, ?, ?, ?, "completed")',
        [userId, subscriptionId, amount, currency, paymentMethod, transactionId]
      );
      
      // تحديث معرف الدفع في الاشتراك
      await pool.query(
        'UPDATE subscriptions SET payment_id = ? WHERE id = ?',
        [result.insertId, subscriptionId]
      );
      
      return {
        success: true,
        paymentId: result.insertId
      };
    } catch (error) {
      console.error('خطأ في إنشاء سجل الدفع:', error);
      throw error;
    }
  }
}

module.exports = new SubscriptionModel();
