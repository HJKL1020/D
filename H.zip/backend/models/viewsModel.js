// viewsModel.js - نموذج طلبات زيادة المشاهدات

const { pool } = require('../config/database');
const config = require('../config/config');

class ViewsModel {
  // إنشاء طلب جديد لزيادة المشاهدات
  async createViewRequest(userId, tiktokUrl, requestedViews) {
    try {
      // التحقق من صلاحية الرابط
      if (!this.validateTikTokUrl(tiktokUrl)) {
        return { success: false, message: 'رابط تيك توك غير صالح' };
      }
      
      // التحقق من الحد الأقصى للمشاهدات المسموح بها للمستخدم
      const [userRows] = await pool.query(
        'SELECT account_type FROM users WHERE id = ?',
        [userId]
      );
      
      if (userRows.length === 0) {
        return { success: false, message: 'المستخدم غير موجود' };
      }
      
      const accountType = userRows[0].account_type;
      const maxViews = config.viewIncrement.maxViews[accountType];
      
      if (requestedViews > maxViews) {
        return { 
          success: false, 
          message: `الحد الأقصى للمشاهدات المسموح بها لحسابك هو ${maxViews} مشاهدة` 
        };
      }
      
      // التحقق من عدد الطلبات الشهرية المسموح بها
      const [planRows] = await pool.query(
        `SELECT p.features
         FROM users u
         JOIN subscriptions s ON u.subscription_id = s.id
         JOIN plans p ON s.plan_id = p.id
         WHERE u.id = ? AND s.status = 'active'`,
        [userId]
      );
      
      let videosPerMonth = 3; // الافتراضي للمستوى المجاني
      
      if (planRows.length > 0) {
        const features = JSON.parse(planRows[0].features);
        videosPerMonth = features.videos_per_month;
      }
      
      // حساب عدد الطلبات في الشهر الحالي
      const [countRows] = await pool.query(
        `SELECT COUNT(*) as count
         FROM view_requests
         WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)`,
        [userId]
      );
      
      const currentMonthRequests = countRows[0].count;
      
      if (currentMonthRequests >= videosPerMonth) {
        return { 
          success: false, 
          message: `لقد وصلت إلى الحد الأقصى من الطلبات المسموح بها هذا الشهر (${videosPerMonth} طلب)` 
        };
      }
      
      // إنشاء الطلب
      const [result] = await pool.query(
        'INSERT INTO view_requests (user_id, tiktok_url, requested_views, status) VALUES (?, ?, ?, "pending")',
        [userId, tiktokUrl, requestedViews]
      );
      
      return {
        success: true,
        requestId: result.insertId,
        message: 'تم إنشاء الطلب بنجاح'
      };
    } catch (error) {
      console.error('خطأ في إنشاء طلب زيادة المشاهدات:', error);
      throw error;
    }
  }
  
  // الحصول على طلبات المستخدم
  async getUserRequests(userId) {
    try {
      const [rows] = await pool.query(
        `SELECT id, tiktok_url, requested_views, current_views, status, created_at, completed_at
         FROM view_requests
         WHERE user_id = ?
         ORDER BY created_at DESC`,
        [userId]
      );
      
      return rows;
    } catch (error) {
      console.error('خطأ في الحصول على طلبات المستخدم:', error);
      throw error;
    }
  }
  
  // الحصول على تفاصيل طلب محدد
  async getRequestDetails(requestId, userId) {
    try {
      // الحصول على تفاصيل الطلب
      const [requestRows] = await pool.query(
        `SELECT id, tiktok_url, requested_views, current_views, status, created_at, completed_at, notes
         FROM view_requests
         WHERE id = ? AND user_id = ?`,
        [requestId, userId]
      );
      
      if (requestRows.length === 0) {
        return null;
      }
      
      const request = requestRows[0];
      
      // الحصول على سجل المشاهدات
      const [logRows] = await pool.query(
        `SELECT id, views_added, timestamp, status
         FROM view_logs
         WHERE request_id = ?
         ORDER BY timestamp ASC`,
        [requestId]
      );
      
      return {
        ...request,
        logs: logRows
      };
    } catch (error) {
      console.error('خطأ في الحصول على تفاصيل الطلب:', error);
      throw error;
    }
  }
  
  // تحديث حالة الطلب
  async updateRequestStatus(requestId, status, notes = null) {
    try {
      let query = 'UPDATE view_requests SET status = ?';
      const params = [status];
      
      if (notes) {
        query += ', notes = ?';
        params.push(notes);
      }
      
      if (status === 'completed') {
        query += ', completed_at = NOW()';
      }
      
      query += ' WHERE id = ?';
      params.push(requestId);
      
      await pool.query(query, params);
      
      return { success: true };
    } catch (error) {
      console.error('خطأ في تحديث حالة الطلب:', error);
      throw error;
    }
  }
  
  // إضافة مشاهدات إلى طلب
  async addViews(requestId, viewsToAdd, batchId) {
    try {
      // الحصول على معلومات الطلب
      const [requestRows] = await pool.query(
        'SELECT user_id, requested_views, current_views, status FROM view_requests WHERE id = ?',
        [requestId]
      );
      
      if (requestRows.length === 0) {
        return { success: false, message: 'الطلب غير موجود' };
      }
      
      const request = requestRows[0];
      
      // التحقق من حالة الطلب
      if (request.status === 'completed' || request.status === 'failed') {
        return { success: false, message: `لا يمكن إضافة مشاهدات لطلب بحالة ${request.status}` };
      }
      
      // التحقق من عدم تجاوز العدد المطلوب
      const remainingViews = request.requested_views - request.current_views;
      
      if (remainingViews <= 0) {
        await this.updateRequestStatus(requestId, 'completed', 'تم إكمال العدد المطلوب من المشاهدات');
        return { success: false, message: 'تم إكمال العدد المطلوب من المشاهدات' };
      }
      
      // تعديل عدد المشاهدات المضافة إذا تجاوز العدد المتبقي
      const actualViewsToAdd = Math.min(viewsToAdd, remainingViews);
      
      // إضافة سجل المشاهدات
      await pool.query(
        'INSERT INTO view_logs (request_id, views_added, batch_id, status) VALUES (?, ?, ?, "success")',
        [requestId, actualViewsToAdd, batchId]
      );
      
      // تحديث عدد المشاهدات الحالية
      const newCurrentViews = request.current_views + actualViewsToAdd;
      await pool.query(
        'UPDATE view_requests SET current_views = ?, status = "processing" WHERE id = ?',
        [newCurrentViews, requestId]
      );
      
      // التحقق مما إذا تم إكمال العدد المطلوب
      if (newCurrentViews >= request.requested_views) {
        await this.updateRequestStatus(requestId, 'completed', 'تم إكمال العدد المطلوب من المشاهدات');
      }
      
      return {
        success: true,
        viewsAdded: actualViewsToAdd,
        currentViews: newCurrentViews,
        isCompleted: newCurrentViews >= request.requested_views
      };
    } catch (error) {
      console.error('خطأ في إضافة المشاهدات:', error);
      throw error;
    }
  }
  
  // الحصول على الطلبات المعلقة للمعالجة
  async getPendingRequests() {
    try {
      const [rows] = await pool.query(
        `SELECT vr.id, vr.user_id, vr.tiktok_url, vr.requested_views, vr.current_views,
         u.account_type
         FROM view_requests vr
         JOIN users u ON vr.user_id = u.id
         WHERE vr.status = 'pending' OR vr.status = 'processing'
         ORDER BY vr.created_at ASC`
      );
      
      return rows;
    } catch (error) {
      console.error('خطأ في الحصول على الطلبات المعلقة:', error);
      throw error;
    }
  }
  
  // حساب عدد المشاهدات التي يجب إضافتها في الدفعة التالية
  calculateNextBatchViews(request, accountType) {
    const totalViews = request.requested_views;
    const currentViews = request.current_views;
    const remainingViews = totalViews - currentViews;
    
    // الحصول على معدل الزيادة حسب نوع الحساب
    const hourlyRate = config.viewIncrement.rates[accountType];
    
    // حساب النسبة المئوية من التقدم
    const progressPercentage = currentViews / totalViews;
    
    let batchPercentage;
    
    // تحديد مرحلة الزيادة بناءً على التقدم الحالي
    if (progressPercentage < 0.15) {
      // مرحلة البداية البطيئة
      batchPercentage = config.viewIncrement.pattern.startup / 3;
    } else if (progressPercentage < 0.50) {
      // مرحلة التسارع
      batchPercentage = config.viewIncrement.pattern.acceleration / 3;
    } else if (progressPercentage < 0.85) {
      // مرحلة الاستقرار
      batchPercentage = config.viewIncrement.pattern.steady / 3;
    } else {
      // مرحلة التباطؤ
      batchPercentage = config.viewIncrement.pattern.slowdown / 3;
    }
    
    // حساب عدد المشاهدات للدفعة التالية
    const batchViews = Math.min(
      Math.ceil(totalViews * batchPercentage),
      Math.ceil(hourlyRate / 3),
      remainingViews
    );
    
    return Math.max(batchViews, 1); // على الأقل مشاهدة واحدة
  }
  
  // التحقق من صحة رابط تيك توك
  validateTikTokUrl(url) {
    return url.startsWith('https://www.tiktok.com/') || url.startsWith('https://vm.tiktok.com/');
  }
}

module.exports = new ViewsModel();
