// server.js - ملف الخادم الرئيسي

const express = require('express');
const cors = require('cors');
const path = require('path');
const bodyParser = require('body-parser');
const { initDatabase } = require('./backend/config/database');
const config = require('./backend/config/config');

// إنشاء تطبيق Express
const app = express();

// إعدادات الوسيطة
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// تقديم الملفات الثابتة
app.use(express.static(path.join(__dirname, 'frontend')));

// تهيئة المسارات
const authRoutes = require('./backend/routes/authRoutes');
const subscriptionRoutes = require('./backend/routes/subscriptionRoutes');
const viewsRoutes = require('./backend/routes/viewsRoutes');
const chatbotRoutes = require('./backend/routes/chatbotRoutes');

// استخدام المسارات
app.use('/api/auth', authRoutes);
app.use('/api/subscriptions', subscriptionRoutes);
app.use('/api/views', viewsRoutes);
app.use('/api/chatbot', chatbotRoutes);

// مسار الصفحة الرئيسية
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});

// تهيئة قاعدة البيانات وبدء الخادم
async function startServer() {
  try {
    // تهيئة قاعدة البيانات
    const dbInitialized = await initDatabase();
    
    if (!dbInitialized) {
      console.error('فشل في تهيئة قاعدة البيانات. إيقاف الخادم.');
      process.exit(1);
    }
    
    // بدء الخادم
    const PORT = process.env.PORT || config.server.port;
    const HOST = config.server.host;
    
    app.listen(PORT, HOST, () => {
      console.log(`الخادم يعمل على المنفذ ${PORT}`);
    });
  } catch (error) {
    console.error('خطأ في بدء الخادم:', error);
    process.exit(1);
  }
}

// بدء الخادم
startServer();
