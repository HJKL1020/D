// chatbot.js - سكريبت روبوت المحادثة الذكي

document.addEventListener('DOMContentLoaded', function() {
    // إنشاء عناصر روبوت المحادثة
    createChatbotElements();
    
    // تهيئة روبوت المحادثة
    initChatbot();
});

// إنشاء عناصر روبوت المحادثة في الصفحة
function createChatbotElements() {
    // إنشاء حاوية الروبوت
    const chatbotContainer = document.createElement('div');
    chatbotContainer.className = 'chatbot-container';
    
    // إنشاء زر الروبوت
    const chatbotButton = document.createElement('div');
    chatbotButton.className = 'chatbot-button';
    chatbotButton.innerHTML = '<i class="fas fa-comment"></i>';
    
    // إنشاء نافذة المحادثة
    const chatbotWindow = document.createElement('div');
    chatbotWindow.className = 'chatbot-window';
    
    // إنشاء رأس نافذة المحادثة
    const chatbotHeader = document.createElement('div');
    chatbotHeader.className = 'chatbot-header';
    chatbotHeader.innerHTML = '<h3>مساعد تيك توك</h3><button class="chatbot-close">&times;</button>';
    
    // إنشاء منطقة الرسائل
    const chatbotMessages = document.createElement('div');
    chatbotMessages.className = 'chatbot-messages';
    
    // إنشاء منطقة الإدخال
    const chatbotInputContainer = document.createElement('div');
    chatbotInputContainer.className = 'chatbot-input-container';
    chatbotInputContainer.innerHTML = `
        <input type="text" class="chatbot-input" placeholder="اكتب رسالتك هنا...">
        <button class="chatbot-send"><i class="fas fa-paper-plane"></i></button>
    `;
    
    // إضافة العناصر إلى نافذة المحادثة
    chatbotWindow.appendChild(chatbotHeader);
    chatbotWindow.appendChild(chatbotMessages);
    chatbotWindow.appendChild(chatbotInputContainer);
    
    // إضافة العناصر إلى حاوية الروبوت
    chatbotContainer.appendChild(chatbotWindow);
    
    // إضافة حاوية الروبوت وزر الروبوت إلى الصفحة
    document.body.appendChild(chatbotContainer);
    document.body.appendChild(chatbotButton);
}

// تهيئة روبوت المحادثة
function initChatbot() {
    const chatbotButton = document.querySelector('.chatbot-button');
    const chatbotWindow = document.querySelector('.chatbot-window');
    const chatbotClose = document.querySelector('.chatbot-close');
    const chatbotInput = document.querySelector('.chatbot-input');
    const chatbotSend = document.querySelector('.chatbot-send');
    const chatbotMessages = document.querySelector('.chatbot-messages');
    
    // فتح/إغلاق نافذة المحادثة عند النقر على زر الروبوت
    chatbotButton.addEventListener('click', function() {
        chatbotWindow.classList.toggle('active');
        chatbotButton.style.display = chatbotWindow.classList.contains('active') ? 'none' : 'flex';
        
        // إذا تم فتح النافذة لأول مرة، نعرض رسالة الترحيب
        if (chatbotWindow.classList.contains('active') && chatbotMessages.children.length === 0) {
            getWelcomeMessage();
        }
    });
    
    // إغلاق نافذة المحادثة عند النقر على زر الإغلاق
    chatbotClose.addEventListener('click', function() {
        chatbotWindow.classList.remove('active');
        chatbotButton.style.display = 'flex';
    });
    
    // إرسال الرسالة عند النقر على زر الإرسال
    chatbotSend.addEventListener('click', function() {
        sendMessage();
    });
    
    // إرسال الرسالة عند الضغط على Enter
    chatbotInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // إضافة اقتراحات الأسئلة الشائعة
    getFAQs();
}

// الحصول على رسالة الترحيب
function getWelcomeMessage() {
    fetch('/api/chatbot/welcome')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                addMessage(data.message.text, true);
                
                // إضافة اقتراحات بعد رسالة الترحيب
                addSuggestions([
                    'كيف يمكنني زيادة المشاهدات؟',
                    'ما هي أسعار الاشتراكات؟',
                    'هل زيادة المشاهدات آمنة؟'
                ]);
            }
        })
        .catch(error => {
            console.error('خطأ في الحصول على رسالة الترحيب:', error);
            addMessage('مرحباً بك! أنا مساعد تيك توك الذكي. كيف يمكنني مساعدتك اليوم؟', true);
        });
}

// الحصول على قائمة الأسئلة الشائعة
function getFAQs() {
    fetch('/api/chatbot/faqs')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.faqs.length > 0) {
                // تخزين الأسئلة الشائعة للاستخدام لاحقاً
                window.chatbotFAQs = data.faqs;
            }
        })
        .catch(error => {
            console.error('خطأ في الحصول على الأسئلة الشائعة:', error);
        });
}

// إرسال رسالة المستخدم ومعالجتها
function sendMessage() {
    const chatbotInput = document.querySelector('.chatbot-input');
    const message = chatbotInput.value.trim();
    
    if (message === '') {
        return;
    }
    
    // إضافة رسالة المستخدم إلى المحادثة
    addMessage(message, false);
    
    // مسح حقل الإدخال
    chatbotInput.value = '';
    
    // إرسال الرسالة إلى الخادم
    fetch('/api/chatbot/message', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message })
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // إضافة رد الروبوت إلى المحادثة
                addMessage(data.response.text, true);
                
                // إضافة اقتراحات بعد رد الروبوت
                if (window.chatbotFAQs && window.chatbotFAQs.length > 0) {
                    // اختيار 3 أسئلة عشوائية من الأسئلة الشائعة
                    const randomFAQs = getRandomFAQs(window.chatbotFAQs, 3);
                    addSuggestions(randomFAQs.map(faq => faq.question));
                }
            }
        })
        .catch(error => {
            console.error('خطأ في إرسال الرسالة:', error);
            addMessage('عذراً، حدث خطأ أثناء معالجة رسالتك. يرجى المحاولة مرة أخرى.', true);
        });
}

// إضافة رسالة إلى المحادثة
function addMessage(text, isBot) {
    const chatbotMessages = document.querySelector('.chatbot-messages');
    
    const messageElement = document.createElement('div');
    messageElement.className = `chatbot-message ${isBot ? 'bot' : 'user'}`;
    messageElement.textContent = text;
    
    chatbotMessages.appendChild(messageElement);
    
    // التمرير إلى أسفل لعرض الرسالة الجديدة
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

// إضافة اقتراحات الأسئلة
function addSuggestions(suggestions) {
    const chatbotMessages = document.querySelector('.chatbot-messages');
    
    // إنشاء حاوية الاقتراحات
    const suggestionsContainer = document.createElement('div');
    suggestionsContainer.className = 'chatbot-suggestions';
    
    // إضافة الاقتراحات
    suggestions.forEach(suggestion => {
        const suggestionElement = document.createElement('div');
        suggestionElement.className = 'chatbot-suggestion';
        suggestionElement.textContent = suggestion;
        
        // إرسال الاقتراح عند النقر عليه
        suggestionElement.addEventListener('click', function() {
            const chatbotInput = document.querySelector('.chatbot-input');
            chatbotInput.value = suggestion;
            sendMessage();
        });
        
        suggestionsContainer.appendChild(suggestionElement);
    });
    
    chatbotMessages.appendChild(suggestionsContainer);
    
    // التمرير إلى أسفل لعرض الاقتراحات
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

// اختيار عناصر عشوائية من مصفوفة
function getRandomFAQs(array, count) {
    const shuffled = [...array].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
}
