// main.js - الملف الرئيسي للجافا سكريبت

// تنفيذ الكود عند اكتمال تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    // تفعيل قسم الأسئلة الشائعة
    setupFAQToggle();
    
    // تفعيل نماذج التسجيل وتسجيل الدخول
    setupForms();
    
    // تفعيل القائمة المتجاوبة للهواتف المحمولة
    setupMobileMenu();
});

// تفعيل قسم الأسئلة الشائعة
function setupFAQToggle() {
    const faqQuestions = document.querySelectorAll('.faq-question');
    
    if (faqQuestions) {
        faqQuestions.forEach(question => {
            question.addEventListener('click', function() {
                // تبديل حالة السؤال النشط
                this.classList.toggle('active');
                
                // الحصول على عنصر الإجابة المرتبط بالسؤال
                const answer = this.nextElementSibling;
                
                // تبديل حالة الإجابة
                if (answer.classList.contains('active')) {
                    answer.classList.remove('active');
                } else {
                    answer.classList.add('active');
                }
            });
        });
    }
}

// تفعيل نماذج التسجيل وتسجيل الدخول
function setupForms() {
    // نموذج التسجيل
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // التحقق من تطابق كلمات المرور
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            
            if (password !== confirmPassword) {
                alert('كلمات المرور غير متطابقة. يرجى المحاولة مرة أخرى.');
                return;
            }
            
            // هنا سيتم إرسال البيانات إلى الخادم (سيتم تنفيذه في مرحلة الواجهة الخلفية)
            alert('تم إنشاء الحساب بنجاح! سيتم إرسال رسالة تأكيد إلى بريدك الإلكتروني.');
            
            // إعادة توجيه المستخدم إلى صفحة تأكيد البريد الإلكتروني (سيتم تنفيذها لاحقًا)
            // window.location.href = 'email-verification.html';
        });
    }
    
    // نموذج تسجيل الدخول
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // هنا سيتم إرسال البيانات إلى الخادم (سيتم تنفيذه في مرحلة الواجهة الخلفية)
            alert('تم تسجيل الدخول بنجاح!');
            
            // إعادة توجيه المستخدم إلى لوحة التحكم (سيتم تنفيذها لاحقًا)
            // window.location.href = 'dashboard.html';
        });
    }
}

// تفعيل القائمة المتجاوبة للهواتف المحمولة
function setupMobileMenu() {
    // إضافة زر القائمة للهواتف المحمولة
    const navMenu = document.querySelector('.nav-menu');
    
    if (navMenu) {
        // إنشاء زر القائمة
        const menuButton = document.createElement('button');
        menuButton.className = 'mobile-menu-button';
        menuButton.innerHTML = '<i class="fas fa-bars"></i>';
        
        // إضافة الزر إلى القائمة
        navMenu.prepend(menuButton);
        
        // تفعيل زر القائمة
        menuButton.addEventListener('click', function() {
            const navLinks = document.querySelector('.nav-links');
            navLinks.classList.toggle('active');
        });
        
        // إضافة تنسيق CSS للقائمة المتجاوبة
        const style = document.createElement('style');
        style.textContent = `
            @media (max-width: 768px) {
                .mobile-menu-button {
                    display: block;
                    background: none;
                    border: none;
                    color: white;
                    font-size: 24px;
                    cursor: pointer;
                }
                
                .nav-links {
                    display: none;
                    width: 100%;
                    flex-direction: column;
                    margin-top: 20px;
                }
                
                .nav-links.active {
                    display: flex;
                }
                
                .nav-links li {
                    margin: 10px 0;
                }
            }
            
            @media (min-width: 769px) {
                .mobile-menu-button {
                    display: none;
                }
            }
        `;
        
        document.head.appendChild(style);
    }
}

// تحقق من صحة رابط تيك توك
function validateTikTokUrl(url) {
    // التحقق من أن الرابط يبدأ بـ https://www.tiktok.com/ أو https://vm.tiktok.com/
    return url.startsWith('https://www.tiktok.com/') || url.startsWith('https://vm.tiktok.com/');
}

// إظهار رسالة تنبيه
function showAlert(message, type = 'error') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    // إضافة التنبيه إلى الصفحة
    document.body.prepend(alertDiv);
    
    // إخفاء التنبيه بعد 5 ثوانٍ
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// تنسيق التنبيهات
const alertStyle = document.createElement('style');
alertStyle.textContent = `
    .alert {
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        padding: 15px 20px;
        border-radius: 5px;
        z-index: 1000;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
    }
    
    .alert-error {
        background-color: #e74c3c;
        color: white;
    }
    
    .alert-success {
        background-color: #2ecc71;
        color: white;
    }
`;

document.head.appendChild(alertStyle);
